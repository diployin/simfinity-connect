ALTER TABLE "users" ADD COLUMN "fcm_token" text;--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN "image_path" text;--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN "deviceid" text;--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN "device_type" text;--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN "device_model" text;--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN "app_version" text;--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN "device_manufacturer" text;--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN "device_location" text;
ALTER TABLE "users" ADD COLUMN "last_low_data_notified_at" timestamp;--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN "last_low_data_level" integer;
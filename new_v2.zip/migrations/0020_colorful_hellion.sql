ALTER TABLE "price_brackets" ADD COLUMN "package_image" text;--> statement-breakpoint
ALTER TABLE "price_brackets" ADD COLUMN "set_price" numeric(10, 2);
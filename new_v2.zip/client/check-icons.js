
const si = require('react-icons/si');
console.log('SiUnionpay:', !!si.SiUnionpay);
console.log('SiDiscover:', !!si.SiDiscover);
